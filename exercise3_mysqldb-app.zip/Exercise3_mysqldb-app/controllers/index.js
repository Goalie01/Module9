module.exports={
    userController: require('./userController'),
    postController: require('./postController'),
    commentController: require('./commentController')
}